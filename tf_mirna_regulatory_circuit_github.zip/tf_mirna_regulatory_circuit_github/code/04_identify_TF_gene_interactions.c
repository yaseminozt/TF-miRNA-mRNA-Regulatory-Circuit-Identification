#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
FILE *TF_fp, *Mi_fp, *Gene_fp,*MiGene_fp,*MiTF_Kontrol_fp,*Sonuc_fp,*MiTF_fp,*TFMi_Kontrol_fp;
char TF[20], MiRNA[20], Gene[20],TF_K[20], MiRNA_K[20]; // dosyadan okuyacağımız verileri kaydetmek için değişken tanımı
//char TF1[540][20], MiRNA1[333][20],Gene1[3132][20]; // Dosyadan okunan veriler için dizi tanımları
//char Mi_Gene1[157590][40]; //103 gen X 1530 MiRNA
int i=0,j,k;
MiTF_Kontrol_fp=fopen("MiTF_kontrol.txt","r"); // Gene dosyasını okumak için açıyoruz
MiTF_fp=fopen("MiTF.txt","r");
Sonuc_fp=fopen("SonucMiTF.txt","w");
//Eğer dosya bulunamazsa hata mesajı verir (Dosyaların program dosyasıyla aynı klasörde bulunması gerekiyor aksi halde yolu vermek gerekir)
if((MiTF_Kontrol_fp==NULL )||(MiTF_fp==NULL))
{ printf("dosya acilamadi");
return 1;
}
//rewind(TMiTF_fp);
fscanf(MiTF_Kontrol_fp,"%s %s",MiRNA_K,TF_K);
k=0;//ortak ikilileri saymak için tutulan değişken
while(!feof(MiTF_Kontrol_fp))
{
rewind(MiTF_fp);
fscanf(MiTF_fp, "%s %s",MiRNA,TF);
while(!feof(MiTF_fp))
{
if(strcmp(TF_K,TF)==0  && strcmp(MiRNA_K,MiRNA)==0 )
{
fprintf(Sonuc_fp, "%s\t%s\n",MiRNA_K,TF_K);
k++;
}
fscanf(MiTF_fp, "%s %s",MiRNA,TF);
}
fscanf(MiTF_Kontrol_fp, "%s %s",MiRNA_K,TF_K);
}
fprintf(Sonuc_fp, "%d tane ortak \n",k);
//Dosyaların kapatılması
fclose(MiTF_fp);
fclose(MiTF_Kontrol_fp);
fclose(Sonuc_fp);
return 0;
}
