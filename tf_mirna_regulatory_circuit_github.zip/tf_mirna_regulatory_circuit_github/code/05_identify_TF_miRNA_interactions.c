#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
FILE *TF_fp, *Mi_fp, *Gene_fp,*MiGene_fp,*MiTF_Kontrol_fp,*Sonuc_fp,*TFGene_fp,*TFGene_Kontrol_fp;
char TF[20], MiRNA[20], Gene[20],TF_K[20], Gene_K[20]; // dosyadan okuyacağımız verileri kaydetmek için değişken tanımı
char TF1[540][20], MiRNA1[333][20],Gene1[3132][20]; // Dosyadan okunan veriler için dizi tanımları
//char Mi_Gene1[157590][40]; //103 gen X 1530 MiRNA
int i=0,j,k;
TFGene_Kontrol_fp=fopen("TFGene_kontrol.txt","r");   // Gene dosyasını okumak için açıyoruz
TFGene_fp=fopen("TFGene.txt","r");
Sonuc_fp=fopen("SonucTFGene.txt","w");
//Eğer dosya bulunamazsa hata mesajı verir (Dosyaların program dosyasıyla aynı klasörde bulunması gerekiyor aksi halde yolu vermek gerekir)
if((TFGene_Kontrol_fp==NULL )||(TFGene_fp==NULL))
{ printf("dosya acilamadi");
return 1;
}
rewind(TFGene_fp);
fscanf(TFGene_Kontrol_fp,"%s %s",TF_K,Gene_K);
k=0;//ortak ikilileri saymak için tutulan değişken
while(!feof(TFGene_Kontrol_fp))
{
rewind(TFGene_fp);
fscanf(TFGene_fp, "%s %s",TF,Gene);
while(!feof(TFGene_fp))
{
if(strcmp(TF_K,TF)==0  && strcmp(Gene_K,Gene)==0 )
{
fprintf(Sonuc_fp, "%s\t%s\n",TF_K,Gene_K);
k++;
}
fscanf(TFGene_fp, "%s %s",TF,Gene);
}
fscanf(TFGene_Kontrol_fp, "%s %s",TF_K,Gene_K);
}
fprintf(Sonuc_fp, "%d tane ortak \n",k);
//Dosyaların kapatılması
fclose(TFGene_fp);
fclose(TFGene_Kontrol_fp);
fclose(Sonuc_fp);
return 0;
}
