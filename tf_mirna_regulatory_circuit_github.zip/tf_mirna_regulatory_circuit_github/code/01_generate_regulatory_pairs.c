**EK-1**
***Transkripsiyon faktörü-miRNA-Hedef gen*** **devrelerinin belirlenmesi için geliştirilen kod**
