#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
FILE *TF_fp, *Mi_fp, *Gene_fp,*MiGene_fp,*MiTF_Kontrol_fp,*SonucMiTFGene_fp,*MiTF_fp;
char TF[20], MiRNA[20], Gene[20],TF_K[20],MiRNA1[20]; // dosyadan okuyacağımız verileri kaydetmek için değişken tanımı
//char TF1[540][20], MiRNA1[333][20],Gene1[3132][20]; // Dosyadan okunan veriler için dizi tanımları
//char Mi_Gene1[157590][40]; //103 gen X 1530 MiRNA
int i=0,j,k;
MiGene_fp=fopen("SonucMiGene.txt","r");  // Gene dosyasını okumak için açıyoruz
MiTF_fp=fopen("SonucMiTF.txt","r");
SonucMiTFGene_fp=fopen("SonucMiTFGene.txt","w");
//Eğer dosya bulunamazsa hata mesajı verir (Dosyaların program dosyasıyla aynı klasörde bulunması gerekiyor aksi halde yolu vermek gerekir)
if((MiGene_fp==NULL ))
{ printf("dosya acilamadi sonuc2");
return 1;
}
//Eğer dosya bulunamazsa hata mesajı verir (Dosyaların program dosyasıyla aynı klasörde bulunması gerekiyor aksi halde yolu vermek gerekir)
if((MiTF_fp==NULL))
{ printf("dosya acilamadi MiTF");
return 2;
}
fscanf(MiGene_fp,"%s %s",MiRNA,Gene);
while(!feof(MiGene_fp))
{
rewind(MiTF_fp);
fscanf(MiTF_fp, "%s %s",MiRNA1,TF);
while(!feof(MiTF_fp))
{
if(strcmp(MiRNA,MiRNA1)==0  )
{
fprintf(SonucMiTFGene_fp, "%s\t%s\t%s\n",MiRNA,TF,Gene);
}
fscanf(MiTF_fp, "%s %s",MiRNA1,TF);
}
fscanf(MiGene_fp,"%s %s",MiRNA,Gene);
}
//Dosyaların kapatılması
fclose(MiGene_fp);
fclose(MiTF_fp);
fclose(SonucMiTFGene_fp);
return 0;
}
