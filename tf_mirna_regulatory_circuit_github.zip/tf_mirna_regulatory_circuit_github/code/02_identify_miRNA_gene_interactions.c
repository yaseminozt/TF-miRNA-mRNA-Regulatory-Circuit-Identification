#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
FILE *TF_fp, *Mi_fp, *Gene_fp,*MiGene_fp,*MiGene_Kontrol_fp,*Sonuc_fp,*TFGene_fp,*MiTF_fp,*TFMi_fp;
char TF[20], MiRNA[20], Gene[20],MiRNA_K[20], Gene_K[20]; // dosyadan okuyacağımız verileri kaydetmek için değişken tanımı
char TF1[886][20], MiRNA1[351][20],Gene1[11068][20]; // Dosyadan okunan veriler için dizi tanımları
//char Mi_Gene1[157590][40]; //103 gen X 1530 MiRNA
int i=0,j,k;
TF_fp=fopen("TF.txt","r"); //TF dosyası okunmak için açılıyor
MiGene_fp=fopen("MiGene.txt","w+"); //MiGene  dosyasını biz oluşturuyoruz Mümkün olan tüm MİRNA ve Gene sembolü ikililerini yazacağız bu dosyaya
Mi_fp=fopen("MiRNA.txt","r"); // MiRNA dosyasını okumak için açıyoruz
Gene_fp=fopen("Gene.txt","r");     // Gene dosyasını okumak için açıyoruz
TFGene_fp=fopen("TFGene.txt","w+");
MiTF_fp=fopen("MiTF.txt","w+");
TFMi_fp=fopen("TFMi.txt","w+");
//Eğer dosya bulunamazsa hata mesajı verir (Dosyaların program dosyasıyla aynı klasörde bulunması gerekiyor aksi halde yolu vermek gerekir)
if((TF_fp==NULL )||(Mi_fp==NULL)||(Gene_fp==NULL)||(MiGene_fp==NULL)||(TFGene_fp==NULL)||(MiTF_fp==NULL)||(TFMi_fp==NULL))
{ printf("dosya acilamadi");
return 1;
}
// TF lerin dosyadan okunup dizi (TF1[]) içerisine aktarılması
i=0;
fscanf(TF_fp, "%s",TF);
while(!feof(TF_fp))
{     strcpy(TF1[i],TF);
i++;
fscanf(TF_fp, "%s",TF);
}
// MiRNA ların dosyadan okunup dizi (MiRNA1[]) içerisine aktarılması
i=0;
fscanf(Mi_fp, "%s",MiRNA);
while(!feof(Mi_fp))
{     strcpy(MiRNA1[i],MiRNA);
i++;
fscanf(Mi_fp, "%s",MiRNA);
}
// Gen sembollerinin dosyadan okunup dizi (Gene1[]) içerisine aktarılması
i=0;
fscanf(Gene_fp,"%s",Gene);
while(!feof(Gene_fp))
{     strcpy(Gene1[i],Gene);
i++;
fscanf(Gene_fp,"%s",Gene);
}
//Mümkün olan tüm miRNA ve Gene ikililerini bir dosyaya (MiGene.txt) yazıyoruz
for(i=0;i<11067;i++)//Gene
{ for(j=0; j<350;j++)//MiRNA
fprintf(MiGene_fp,"%s\t%s\n",MiRNA1[j],Gene1[i]);
}
for(j=0; j<885;j++)//TF
{ for(i=0;i<11067;i++)//Gene
fprintf(TFGene_fp,"%s\t%s\n",TF1[j],Gene1[i]);
}
for(i=0;i<350;i++)//MiRNA
{ for(j=0; j<885;j++)//TF
fprintf(MiTF_fp,"%s\t%s\n",MiRNA1[i],TF1[j]);
}
for(j=0; j<885;j++)//TF
{ for(i=0;i<350;i++)//MiRNA
fprintf(TFMi_fp,"%s\t%s\n",TF1[j],MiRNA1[i]);
}
//Dosyaların kapatılması
fclose(TF_fp);
fclose(Mi_fp);
fclose(Gene_fp);
fclose(MiGene_fp);
fclose(TFGene_fp);
fclose(MiTF_fp);
fclose(TFMi_fp);
return 0;
}
