# Input files

Place the required input files in this directory when preparing a reproducible
run. The source programs currently expect the files to be available in the
working directory.

Required filenames may include:

- TF.txt
- MiRNA.txt
- Gene.txt
- MiGene_kontrol.txt
- MiTF_kontrol.txt
- TFGene_kontrol.txt
- TFMi_kontrol.txt

Large or database-derived input files can be excluded from the repository and
their source/accession information documented in the manuscript or README.
